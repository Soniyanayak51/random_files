#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
int cmp(char word[],char mean[])
{
	int n1=sizeof(word)/sizeof(word[0]);
	int n2=sizeof(mean)/sizeof(mean[0]);
	if(n1!=n2)
	return 1;
	int i;	
	for(i=0;i<n1;i++)
	{
		if(word[i]!=mean[i])
			return 1;
		if(word[i]=='\0' && mean[i]=='\0')
			return 0;	
	}
	return 0;
}
int main()
{
	int ssock,csock;
	// creating server and client socket discriptor
	int a,b,c;
	unsigned int len;
	struct sockaddr_in server,client;
	// creating server & client socket object
	if((ssock=socket(AF_INET,SOCK_STREAM,0))==-1)
	// creating socket
	{
		perror("socket: ");
		exit(-1);
	}
	server.sin_family=AF_INET;
	server.sin_port=htons(10000);
	// initializing server socket parameters.
	server.sin_addr.s_addr=INADDR_ANY;
	bzero(&server.sin_zero,0);
	// appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.
	len=sizeof(struct sockaddr_in);
	if((bind(ssock,(struct sockaddr *)&server,len))==-1)
	// binding port & IP
	{
		perror("bind error: ");
		exit(-1);
	}
	if((listen(ssock,5))==-1)
	// listening for client
	{
		perror("listen error: ");
		exit(-1);
	}
	if((csock=accept(ssock,(struct sockaddr *)&client,&len))==-1)
	// accepting connection
	{
		perror("accept error: ");
		exit(-1);
	}
	while(1)
	{
		int a,b,l;
		recv(csock,&a,sizeof(a),0);
		printf("hi\n");
		recv(csock,&b,sizeof(b),0);
		FILE *fptr,*fptr1;
		fptr=fopen("dictionary","r");
		fptr1=fopen("new","w");
		if(!fptr || !fptr1)
		{
			printf("FILE not open");
		}
		else
		{
			;
			int flag=0;
			int x,cl,el,ncl,nel;
			recv(csock,&l,sizeof(a),0);
			while(!feof(fptr))
			{
				fscanf(fptr,"%d",&x);
				fscanf(fptr,"%d",&cl);
				fscanf(fptr,"%d",&el);			
				if(flag==0 && a==x)
				{

					if(b==0)
					{
						if(cl>=l)
						{
							flag=1;
							cl-=l;
						}
					}
					else
					{				
						if(el>=l)
						{
							flag=1;
							el-=l;
							l=el;
						}
					}
					ncl=cl;
					nel=el;
				}
				fprintf(fptr1,"%d\n",x);
				fprintf(fptr1,"%d\n",cl);
				fprintf(fptr1,"%d\n",el);
			}
			fclose(fptr);
			fclose(fptr1);
			remove("dictionary");
			rename("new","dictionary");
			send(csock,&flag,sizeof(flag),0);
			send(csock,&ncl,sizeof(ncl),0);
			send(csock,&nel,sizeof(nel),0);
		}
		// sending data to client.
		printf("\ntask completed\n");
	}
	close(ssock);
}
