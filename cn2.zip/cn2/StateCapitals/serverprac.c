#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
int main()
{
int ssock,csock;
// creating server and client socket discriptor
char ar[100];
char str2[100];
char str1[100];
int n;
int k;
k=5;
unsigned int len;
struct sockaddr_in server,client;
// creating server & client socket object
if((ssock=socket(AF_INET,SOCK_STREAM,0))==-1)
// creating socket
{
perror("socket: ");
exit(-1);
}
server.sin_family=AF_INET;
server.sin_port=htons(10000);
// initializing server socket parameters.
server.sin_addr.s_addr=INADDR_ANY;
bzero(&server.sin_zero,0);
// appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.
len=sizeof(struct sockaddr_in);
if((bind(ssock,(struct sockaddr *)&server,len))==-1)
// binding port & IP
{
perror("bind error: ");
exit(-1);
}
if((listen(ssock,5))==-1)
// listening for client
{
perror("listen error: ");
exit(-1);
}
if((csock=accept(ssock,(struct sockaddr *)&client,&len))==-1)
// accepting connection
{
perror("accept error: ");
exit(-1);
}
while(1)
{
//recv(csock,&a,sizeof(a),0);
recv(csock,&ar,sizeof(ar),0);
FILE *fptr,*fpt;
fptr=fopen("capitals.txt","r+");
if(fptr==NULL)
printf("Failed\n");
else{
int i;
for(i=1;i<=k;i++)
{
fscanf(fptr,"%s%s",str1,str2);
printf(" %s\n",str1);
if(strcmp(str1,ar)==0)
{
printf("Capital is: %s\n",str2);
send(csock,&str2,sizeof(str2),0);
break;
}
else if(strcmp(str2,ar)==0)
{
printf("state is: %s\n",str1);
send(csock,&str1,sizeof(str1),0);
break;
}
}
fclose(fptr);
if(i>k)
{
fpt=fopen("capitals.txt","a");
if(fpt==NULL)
printf("error");
else
{printf("Not found\nEnter the capital\n");
scanf("%s",str2);
k++;
fprintf(fpt,"%s %s ",ar,str2);
//rewind(fpt);
send(csock,&str2,sizeof(str2),0);
}
fclose(fpt);
}}
// sending data to client.
//printf("\nsent address= %s\n",ans);
}
close(ssock);
}

