#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>        
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

int cmp(char word[100],char word2[100])
{
 //int n=word2.length();
int n=strlen(word2);

  int i;
for( i=0;i<n;i++)
{
  if(word[i]!=word2[i])
    return 0;
}
return 1;
}
int main()
{



 FILE *fptr;
fptr = fopen("dictionary.txt","w");

 if(fptr == NULL)
{
printf("Error file not open !");

}
printf("file opened \n");
int i;
printf("enter two word an their meaning \n");

for(i=0;i<2;i++)
{
char aword[100];
char amean[100];
scanf("%s",aword);
   gets(amean); 
fprintf(fptr,"%s \n",aword);
fprintf(fptr,"%s \n",amean);

}
 fclose(fptr);

 /*


FILE *ofptr;
if ((ofptr = fopen("dictionary.txt","r")) == NULL){
printf("Error! opening file");
}


char serword[100]="you";

char testword[100]="you";

    while (fgets(scanword , sizeof(scanword) ,ofptr )!= NULL)
   {
printf("%s",scanword);
      if (cmp(scanword , serword ))
      {
         printf("found \n");
break;
      }
//printf("      dnjknjkd \n");
   }
fgets(scanword , sizeof(scanword) ,ofptr );
printf("%s ",scanword);

fclose(ofptr);


*/

int ssock,csock;      
 
struct sockaddr_in server,client;  
 
if((ssock=socket(AF_INET,SOCK_STREAM,0))==-1){    

    perror("socket: ");
    exit(-1);
}

printf("socket created \n");


server.sin_family=AF_INET;
server.sin_port=htons(10000);      
server.sin_addr.s_addr=INADDR_ANY;
 

bzero(&server.sin_zero,0);


int len=sizeof(struct sockaddr_in);
 
if((bind(ssock,(struct sockaddr *)&server,len))==-1){
    perror("bind error: ");
    exit(-1);
}

printf("port and ip binded \n");

 
if((listen(ssock,5))==-1){    

    perror("listen error: ");                    
    exit(-1);
}
printf("listing the client \n");

if((csock=accept(ssock,(struct sockaddr *)&client,&len))==-1){  

    perror("accept error: ");                        
    exit(-1);
}

printf("accepted the clinet ... \n");



    //recv(csock,&pas,sizeof(pas),0);

       // send(csock,&sendn,sizeof(sendn),0);
    

          
           
           while(1){
                  char word[100];
char notf[100]="not-found";


               char scanword[100];

                  recv(csock,word,sizeof(word),0);
                  int check=0;
printf("%s \n",word);
FILE *ofptr;
if ((ofptr = fopen("dictionary.txt","r")) == NULL){
printf("Error! opening file");
}
              while (fgets(scanword , sizeof(scanword) ,ofptr )!= NULL)
  			 {
 
				//printf("%s",scanword);
     			 	if (cmp(scanword , word ))
      					{
					check=1;
         				printf("found \n");
					break;
      					}

   			}
		fgets(scanword , sizeof(scanword) ,ofptr );
		printf("%s ",scanword);

		fclose(ofptr);
                send(csock,&check,sizeof(check),0);
                if(check)
                send(csock,scanword,sizeof(scanword),0);
                  else
                 {
                  char recme[100];
                 send(csock,notf,sizeof(notf),0);
                  recv(csock,recme,sizeof(recme),0);

                   FILE *afptr;
		if ((afptr = fopen("dictionary.txt","a")) == NULL){
			printf("Error! opening file");
				}
                   fprintf(afptr,"%s \n",word);
		   fprintf(afptr,"%s \n",recme);
                  
                   fclose(afptr);

                 }                  

                  //send(csock,answ,sizeof(answ),0);
                 }
       
                  


 
 
close(ssock);

 



}


