#include<bits/stdc++.h>
using namespace std;

int xr[20],yr[20],zr[20];
int xa[20],ya[20],za[20];

void fun(int x,int y,int z,vector<int> vis,vector<int> ans,int n){
	if(ans.size()==n){
		cout<<"Sequence::"<<endl;
		for(int i=0;i<n;i++){
			cout<<ans[i]<<" ";
		}
		cout<<endl;
		return;
	}
	for(int i=0;i<n;i++){
		if(!vis[i]){
			if(xr[i]<=x && yr[i]<=y && zr[i]<=z){
				ans.push_back(i);
				vis[i] = 1;
				fun(x+xa[i],y+ya[i],z+za[i],vis,ans,n);
				ans.pop_back();
				vis[i]=0;	
			}
		}
	}
}

int main(){

	int n;
	cout<<"Enter No. of processes"<<endl;
	cin>>n;
	int x1=0,y1=0,z1=0;
	cout<<"Enter Allocated and requested resources"<<endl;
	for(int i=0;i<n;i++){
		cin>>xa[i]>>ya[i]>>za[i]>>xr[i]>>yr[i]>>zr[i];
		x1 += xa[i];
		y1 += ya[i];
		z1 += za[i];
	}

	int xt,yt,zt;
	cout<<"Enter Max available quantities"<<endl;
	cin>>xt>>yt>>zt;

	x1 = xt-x1,y1=yt-y1,z1=zt-z1;
	
	vector<int> vis(n,0);
	vector<int> ans;
	fun(x1,y1,z1,vis,ans,n);

	
}
