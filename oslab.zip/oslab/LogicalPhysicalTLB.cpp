#include<bits/stdc++.h>
using namespace std;
int main()
{
int m,n,d;
cout<<"ENTER m\n";
cin>>m;
cout<<"ENTER n\n";
cin>>n;
cout<<"ENTER d\n";
cin>>d;
string s;
cout<<"ENTER LOGICAL ADDRESS\n";
cin>>s;
int t1,t2;
cout<<"ENTER t1\n";
cin>>t1;
cout<<"ENTER t2\n";
cin>>t2;
int val=pow(2,m-d);
vector<int> pgtab(val);
int mod=pow(2,n-d);
for(int i=0;i<val;i++)
{
pgtab[i]=(rand())%mod;
}
cout<<"PAGE TABLE=>\n";
for(int i=0;i<val;i++)
{
cout<<i<<"==>"<<pgtab[i]<<'\n';
}
int no=m-d-1;
int ans=0;
for(int i=0;i<m-d;i++)
{
ans+=pow(2,no)*(s[i]-'0');
no--;
}
int time=t1+t2;
if(ans%2!=0)
{
time+=t1;
}
cout<<"TLB\n";
for(int i=0;i<val;i+=2)
{
cout<<i<<"==>"<<pgtab[i]<<"\n";
}
ans=pgtab[ans];
string s1;
while(ans>0)
{
s1+=ans%2+'0';
ans=ans/2;
}
cout<<"PHYSICAL ADDRESS\n";
for(int i=s1.length()-1;i>=0;i--)
{
cout<<s1[i];
}
for(int i=m-d;i<m;i++)
{
cout<<s[i];
}cout<<'\n';
cout<<"TIME=>"<<time<<'\n';
}