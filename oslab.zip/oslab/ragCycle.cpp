#include<bits/stdc++.h>
using namespace std;
bool dfs(vector<int> adj[],int n,vector<bool> &vis,int s)
{
	vis[s]=true;
	bool flag=false;
	for(int i=0;i<adj[s].size();i++)
	{
		if(!vis[adj[s][i]])
		{
			flag=flag || dfs(adj,n,vis,adj[s][i]);
		}
		else
		{
			return true;
		}
	}
	vis[s]=false;
	return flag;
}
int main()
{
	int n;
	cout<<"ENTER NUMBER OF NODES\n";
	cin>>n;
	vector<int> adj[n+1];
	int m;
	cout<<"ENTER ALLOCATION NUMBER\n";
	cin>>m;
	cout<<"ENTER GRAPH\n";
	for(int i=0;i<m;i++)
	{
		int x,y;
		cin>>x>>y;
		adj[x].push_back(y);
	}
	vector<bool> vis(n+1,false);
	bool flag=false;
	for(int i=1;i<=n;i++)
	{	
		if(!vis[i]){
		if(dfs(adj,n,vis,i))
		{
			flag=true;
			break;
		}}
	}
	if(flag)
	{
		cout<<"CYCLE FOUND\n";
	}
	else
	{
		cout<<"CYCLE NOT FOUND\n";
	}
}
