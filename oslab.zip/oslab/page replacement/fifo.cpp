#include<bits/stdc++.h>
using namespace std;

int main()
{	
	int n, f, miss = 0, flag;
	cout<<"Enter no. of elements::\n";
	cin>>n;
	cout<<"Enter frame size::\n";
	cin>>f;
	cout<<"Enter elements::\n";
	vector<int> ar(n, 0);
	for(int i = 0; i<n; i++)
	{
		cin>>ar[i];
	}
	set<int> s;
	queue<int> cur_frame;
	for(int i = 0; i<n; i++)
	{
		flag = 0;
		if(s.size()<f)
		{
			if(s.find(ar[i]) == s.end())
			{
				miss++;
				s.insert(ar[i]);
				cur_frame.push(ar[i]);
				flag = 1;
			}
		}
		else
		{
			if(s.find(ar[i]) == s.end())
			{
				miss++;
				int fr = cur_frame.front();
				cur_frame.pop();
				s.erase(fr);
				s.insert(ar[i]);
				cur_frame.push(ar[i]);
				flag = 1;
			}
		}
		if(flag == 1)
		cout<<"M";
		else cout<<"H";
	}
	cout<<endl<<"No.of misses:: "<<miss<<endl<<"No. of hits:: "<<n-miss<<endl;
	
}
