#include<bits/stdc++.h>
using namespace std;
bool search(int key, vector<int>&fr)
{
    for(int i = 0; i< fr.size(); i++)
    {
        if(fr[i] == key)
        return true;
    }
    return false;
}
int whattoreplace(vector<int> ar, int n, vector<int> fr, int ind)
{
    int far = ind,ans = 0;
    for(int i = 0; i<fr.size(); i++)
    {
        int j;
        for(j = ind;j<n;j++)
        {
            if(ar[j] == fr[i])
            {
                if(j>far)
                {
                    far = j;
                    ans = i;
                }
                break;
            }
            
        }
        if(j == n)
        return i;
    }
    return ans;
}
int main()
{
    int n;
    cin>>n;
    int f;
    cin>>f;
    vector<int> ar(n);
    for(int i = 0; i<n; i++)
    {
        cin>>ar[i];
    }
    int u = 0 ;
    
    vector<int> fr;
    int hit = 0, fl = 0;
    for(int i = 0; i<n; i++)
    {
        fl = 0;
        if(search(ar[i], fr))
        {
           hit++;
            fl = 1;
          
        }
        else if(f>fr.size())
        {
            fr.push_back(ar[i]);
        }
        
        else 
        {
            int h = whattoreplace(ar, n, fr, i+1);
            fr[h] = ar[i];
        }
        if(fl == 1)
        cout<<"H";
        else cout<< "M";
       
    }
    cout<<endl<<"no. of hits::"<<hit<<endl<<"no. of miss::"<<n-hit<<endl;
    
}