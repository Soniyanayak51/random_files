#include<bits/stdc++.h>
using namespace std;
int findLRU(int time[], int n)
{
	int i, minimum = time[0], pos = 0;
	 
	for(i = 1; i < n; ++i)
	{
		if(time[i] < minimum)
		{
			minimum = time[i];
			pos = i;
		}
	}
	return pos;
}
int main()
{	
	int n, f, miss = 0, flag, counter = 0, pos;
	cout<<"Enter no. of elements::\n";
	cin>>n;
	cout<<"Enter frame size::\n";
	cin>>f;
	cout<<"Enter elements::\n";
	vector<int> ar(n, 0);
	int frames[10], time[40];
	for(int i = 0; i<n; i++)
	{
		cin>>ar[i];
	}
	for(int i = 0; i < f; ++i)
	{
     	frames[i] = -1;
     }
    int fl = 0, flag1, flag2, i, j;
    for(i = 0; i < n; ++i)
    {
		flag1 = flag2 = 0;
	     fl = 0;
		for(j = 0; j < f; ++j)
		{
			if(frames[j] == ar[i])
			{
				counter++;
				time[j] = counter;
				flag1 = flag2 = 1;
				break;
			}
		}
	    
		if(flag1 == 0)
		{
			for(j = 0; j < f; ++j)
			{
				if(frames[j] == -1)
				{
					counter++;
					miss++;
					frames[j] = ar[i];
					time[j] = counter;
					flag2 = 1;
					fl = 1;
					break;
				}
			}	
		}
	    
		if(flag2 == 0)
		{
			pos = findLRU(time, f);
			counter++;
			miss++;
			frames[pos] = ar[i];
			time[pos] = counter;
			fl = 1;
		}
	    
	     if(fl == 1)
	     {
	     	cout<<"M";
	     }
	     else cout<<"H";
	}
	cout<<endl<<"No.of misses:: "<<miss<<endl<<"No. of hits:: "<<n-miss<<endl;	
}
