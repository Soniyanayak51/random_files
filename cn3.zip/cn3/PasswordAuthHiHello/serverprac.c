#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>         
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>


int main(){

int ssock,csock;      
 // creating server and clinet socket discriptor
char n[100], pass[] = "pass1", greet[100];
char word[100];
int number;
unsigned int len;

struct sockaddr_in server,client;   
// creating server & client socket object

if((ssock=socket(AF_INET,SOCK_STREAM,0))==-1){     
// creating socket
	perror("socket: ");
	exit(-1);
}

server.sin_family=AF_INET;
server.sin_port=htons(10000);       

// initializing server socket parameters..
server.sin_addr.s_addr=INADDR_ANY;

//inet_addr("127.0.0.1");
bzero(&server.sin_zero,0); 

//appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.. 


len=sizeof(struct sockaddr_in);

if((bind(ssock,(struct sockaddr *)&server,len))==-1){ 
 // binding port & IP  
	perror("bind error: ");
	exit(-1);
}

if((listen(ssock,5))==-1){     
// listening for client
	perror("listen error: ");                     
	exit(-1);
}


if((csock=accept(ssock,(struct sockaddr *)&client,&len))==-1){  
// accepting connectn
	perror("accept error: ");                         
	exit(-1);
}
while(1){
char c[100];
	recv(csock, n,sizeof(n),0);
	recv(csock, greet,sizeof(greet),0);
	if(strcmp(n, pass) == 0)
	strcpy(c, "Hello");
	else strcpy(c, "Wrong");
	send(csock,&c,sizeof(c),0);     
	recv(csock, word,sizeof(word),0);      
	recv(csock, &number,sizeof(number),0);

int arr[26];
memset(arr,0,sizeof(arr));

int i=0;
while(word[i]!='\0')
{
   arr[word[i]-'a']++;
    i++;
}

char cc;
for( i=0;i<26;i++)
{
    if(arr[i]==number)
    {
        cc=i+'a';
   break;
    }
}


send(csock,&cc,sizeof(cc),0);
 // sending data to client...	
	printf("\nsent letter=: %c\n",cc);

}


close(ssock);









}

