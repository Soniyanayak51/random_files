#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>         
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>


int main(){
int sock;      // client socket discriptor
int i;
char s[100], c[100], hi[100];
unsigned int len;
char ch[3]="no";
char ch1[3];
char word[100];
int number;
char letter;
struct sockaddr_in client;
if((sock=socket(AF_INET,SOCK_STREAM,0))==-1){  // client socket is created..
perror("socket: ");
exit(-1);
}

client.sin_family=AF_INET;
client.sin_port=htons(10000);        // initializing  socket  parameters 
client.sin_addr.s_addr=INADDR_ANY;
//inet_addr("127.0.0.1");
bzero(&client.sin_zero,0); //appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.. 


len=sizeof(struct sockaddr_in);
if((connect(sock,(struct sockaddr *)&client,len))==-1){  //conneting to client
perror("connect: ");
exit(-1);
}
while(1){
printf("Enter the password:\n");
scanf("%s", s);

send(sock,s,sizeof(s),0);     // sending data back to client...
printf("Say Hi to the server:\n");
scanf("%s", hi);
send(sock, hi,sizeof(hi),0);
recv(sock, c,sizeof(c),0);
char one[] = "Hello"; 
if(strcmp(c, one) == 0)
{
printf("%s", c);
printf("Enter the word::\n");
scanf("%s", word);
printf("Enter the number::\n");
scanf("%d", &number);
send(sock,word,sizeof(word),0);
send(sock,&number,sizeof(number),0);
recv(sock, &letter,sizeof(letter
),0);
printf("The result is::\n");
printf("%c", letter);
}
else printf("Wrong password!");

                           // receiving data from client
printf("\nTo exit...press 'no'\n");


scanf("%s",ch1);
//printf("%s\n",ch1);
//printf("%s\n",ch);

if((i=strcmp(ch,ch1))==0){
close(sock);
exit(0);
}

}

}

