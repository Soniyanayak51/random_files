#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>         
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>


int main(){
int sock;      // client socket discriptor
int a,b,c,i;
unsigned int len;
char ch[3]="no";
char ch1[3];

struct sockaddr_in client;
if((sock=socket(AF_INET,SOCK_STREAM,0))==-1){  // client socket is created..
perror("socket: ");
exit(-1);
}

client.sin_family=AF_INET;
client.sin_port=htons(1083);        // initializing  socket  parameters 
client.sin_addr.s_addr=INADDR_ANY;
//inet_addr("127.0.0.1");
bzero(&client.sin_zero,0); //appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.. 


len=sizeof(struct sockaddr_in);
if((connect(sock,(struct sockaddr *)&client,len))==-1){  //conneting to client
perror("connect: ");
exit(-1);
}

char* s[30];
s[0]="a";
s[1]="b";
s[3]="c";
s[4]="d";
s[5]="e";
s[6]="f";
s[7]="g";
s[8]="h";
s[9]="i";
s[10]="j";
s[11]="k";
s[12]="l";
s[13]="m";
s[14]="n";
s[15]="o";
s[16]="p";
s[17]="q";
s[18]="r";
s[19]="s";
s[20]="t";


while(1){

int num;
printf("\n enter any number between 1 - 20: ");
scanf("%d",&num);

char* sal;
sal=s[num];
send(sock,sal,sizeof(sal),0);
printf("\n word sent. ");

char c1[100], c2[100];
recv(sock,c1,sizeof(c1),0);
printf("%s\n",c1);
printf("\nTo exit...press 'no'\n");

scanf("%s",ch1);
//printf("%s\n",ch1);
//printf("%s\n",ch);

if((i=strcmp(ch,ch1))==0){
close(sock);
exit(0);
}

}

}
