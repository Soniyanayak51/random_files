#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>         
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

int findName(char* clientSearch, char* serverResult)
{
  FILE *filename=fopen("file.txt","r");
  char temp[256];
  bzero(temp,256);
  while (filename!=NULL && fgets(temp, sizeof(temp),filename) != NULL)
    {
      if (strstr(temp, clientSearch))
    {
      //printf("temp is: %s", temp);
      strncpy(serverResult,temp, sizeof(temp));
      return 1;
    }
    }
  if (filename!=NULL) fclose(filename);
  return 0;
}

int main()
{

int ssock,csock;      
 // creating server and clinet socket discriptor

unsigned int len;

struct sockaddr_in server,client;   
// creating server & client socket object

if((ssock=socket(AF_INET,SOCK_STREAM,0))==-1){     
// creating socket
	perror("socket: ");
	exit(-1);
}

server.sin_family=AF_INET;
server.sin_port=htons(1083);       

// initializing server socket parameters..
server.sin_addr.s_addr=INADDR_ANY;

//inet_addr("127.0.0.1");
bzero(&server.sin_zero,0); 

//appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.. 


len=sizeof(struct sockaddr_in);

if((bind(ssock,(struct sockaddr *)&server,len))==-1){ 
 // binding port & IP  
	perror("bind error: ");
	exit(-1);
}

if((listen(ssock,5))==-1){     
// listening for client
	perror("listen error: ");                     
	exit(-1);
}


if((csock=accept(ssock,(struct sockaddr *)&client,&len))==-1){  
// accepting connectn
	perror("accept error: ");                         
	exit(-1);
}

char a[100];
while(1)
{
recv(csock,a,sizeof(a),0);
printf("word recieved\n");
       
char aa[100];
if(findName(a,aa))
{
    printf("word found\n");
    
 int i=0;
     while(aa[i]!='_')
           i++;
    i++;
int k=0;
char jh[100];
   while(aa[i]!='\0')
    {
           jh[k]=aa[i];
             i++;
              k++;
   }
    send(csock,jh,sizeof(jh),0); 
}

else{char mean[100] = "meaning";
printf("word not found\n");
printf("adding word to dictionary\n");
char add[100];
add[0]=a[0];
add[1]='_';
int k=2, i=0;
 while(mean[i]!='\0')
    {
           add[k]=mean[i];
             i++;
              k++;
   }
add[k]='\n';
FILE *p;
p=fopen("file.txt", "a");
fputs(add, p);
fclose(p);
}

}


close(ssock);

}








